# write aprogram to accept author,publication display list of books of the author-publication combination

import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

auth=input('Enter a author : ')
pub=int(input('Enter a publication : '))

curs.execute("select * from books where author='%s' and publication=%d" %(auth,pub))
data=curs.fetchall()
#print(data)
 
for rec in data:
    print(list(rec))

con.close()