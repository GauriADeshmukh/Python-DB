# write a program to accept a category and display list of books

import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

cag=input('Enter a category of book :')
print('select * from books where category="%s" '%cag)

curs.execute('select * from books where category="%s" '%cag)
data=curs.fetchall()

for rec in data:
    print('%s' %(rec[1]))

con.close()
