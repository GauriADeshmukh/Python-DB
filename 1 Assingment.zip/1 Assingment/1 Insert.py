#Write a program to take a input and new books to the DB table

import pymysql

bc=int(input('Enter a bookcode : '))
bn=input('Enter a bookname : ')
cag=input('Enter a category of book : ') 
auth=input('Enter the author : ')
pub=int(input('Enter the publication : '))
edit=(input('Enter a edition of book : '))
pri=float(input('Enter a price of book : '))

try:
    con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
    curs=con.cursor()
    curs.execute("insert into books values(%d,'%s','%s','%s',%d,'%s',%.2f)" %(bc,bn,cag,auth,pub,edit,pri))
    con.commit()
    
    print('New book added sucessfully')
except Exception as e:
    print('Data insert failed -',e)
 
con.close()
