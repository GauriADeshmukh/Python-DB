# write a program to accept bookcode, search book in table, show the book details

import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

bc=int(input('Enter a Bookcode :'))
print('select * from  books where bookcode=%d' %bc)

curs.execute('select * from books where bookcode=%d' %bc)
data=curs.fetchone()

try:
    print( 'bookname:%s | category:%s | author:%s | publication:%d | edition:%s | price:%.2f' %(data[1],data[2],data[3],data[4],data[5],data[6]))

except:
    print('not found')

con.close()
