# write a program to accept bookcode and review, update the record with the review contents

import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

try:
    bc=int(input("Enter Bookcode : "))
    curs.execute("select * from books where bookcode = %d" %bc)
    data=curs.fetchone()
    
    if data:
        rec=int(input("Ente: "))
        curs.execute("update books set record where bookcode = %d" %(rec,bc))
        con.commit()
        print("Reciew updated sucessfully...")

    else:
        print("Invalid Input")

except:
    print("Book does not exist")


con.close()
