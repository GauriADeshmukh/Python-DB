# write a program to accept bookcode,display the book data and ask to delete the data

from tkinter.messagebox import NO, YES
import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

try:
    bc=int(input('Enter a Bookcode : '))
    curs.execute('select * from books where bookcode=%d' %bc)
    data=curs.fetchone()
    ch=input('Do you want to delete the data? : ')
    if ch==YES:
        print(data)
        curs.execute("delete from books where bookcode=%d" %bc)
        con.commit()
        print("Book deleted....")
    else:
        print("The book was not deleted.")
except:
    print('can not delete the book')

con.close()

