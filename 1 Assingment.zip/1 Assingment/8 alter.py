# Add new column "review varchar(500)" to the books table using alter query

import pymysql

con=pymysql.connect(host='bfwkguyldw6s6flf4for-mysql.services.clever-cloud.com',user='uzl13b3zlgskta8t',password='4hQNW8IUFmB1JwSA5BgH',database='bfwkguyldw6s6flf4for')
curs=con.cursor()

curs.execute("alter table books add reviev varchar(500)")
print("column Added Sucessfully...")

con.close()